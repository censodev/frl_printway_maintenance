In the project directory, to start project you can run:

### `yarn start`

Change REACT_APP_CUSTOM_STATIC_API_URL in .env file before deploy:

### For dev: https://pgc.goofinity.com/

### For product: https://app-v2.pgcfulfillment.com/

Change upload.sh file before deploy:

### For dev: scp build.zip root@139.180.133.121:~/pgc-admin

### For product: scp -i ~/.ssh/goofinity_rsa build.zip root@128.199.198.49:~/pgc-admin


To build and deploy:

### `source upload.sh`

