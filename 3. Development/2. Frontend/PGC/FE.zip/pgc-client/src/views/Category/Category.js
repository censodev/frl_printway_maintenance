import React, {Component} from 'react';

class Category extends Component {
    render() {
        return (
            <div>
                Category
            </div>
        );
    }
}

Category.propTypes = {};

export default Category;
